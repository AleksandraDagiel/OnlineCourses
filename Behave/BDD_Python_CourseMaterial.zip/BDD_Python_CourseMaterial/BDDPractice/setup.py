# from distutils.core import setup
from setuptools import setup, find_packages
setup(name='BDDPractice',
      version='1.0',
      description='Python BDD Practical Examples',
      author='Admas Kinfu',
      author_email='admaskinfu@gmail.com',
      url='https://www.supersqa.com/',
      packages= find_packages()
     )

