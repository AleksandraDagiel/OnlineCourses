
URLCONFIG = {

        'python.org': 'https://www.python.org/ ',
        'home': '/',
        'base_url': 'http://mystore.local',
        'my account': '/my-account'

}