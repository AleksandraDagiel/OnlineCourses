

def assert_text_visible(text):
    """
    method to assert text is visible on the page
    :param text:
    :return:
    """
    # all_text = driver.get_visible_text()
    print("##########################")
    # assert text.lower() in all_text.lower(), "The text '{}' is not displayed on the page".format(text)