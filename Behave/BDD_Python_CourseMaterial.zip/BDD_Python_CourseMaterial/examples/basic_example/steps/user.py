from behave import then, given

@given('I create a user')
def user_creator():
    """
    Function that actuly creates the user
    :return:
    """
    print('@@@@@@@@@@@@@@@')
    print('I am the one creating users')
    print('@@@@@@@@@@@@@@@')